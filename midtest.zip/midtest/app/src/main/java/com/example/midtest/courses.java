package com.example.midtest;

public class courses {
    private  String cname;
    private  int cfees;
    private  int chours;

    public courses(String cname, int cfees, int chours) {
        this.cname = cname;
        this.cfees = cfees;
        this.chours = chours;
    }

    public String getCname() {
        return cname;
    }

    public int getCfees() {
        return cfees;
    }

    public int getChours() {
        return chours;
    }

    public void setCname(String cname) {

        this.cname = cname;
    }

    public void setCfees(int cfees) {
        this.cfees = cfees;
    }

    public void setChours(int chours) {
        this.chours = chours;
    }
}

