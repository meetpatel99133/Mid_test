package com.example.midtest;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class courseDeatils extends AppCompatActivity implements AdapterView.OnItemSelectedListener, CompoundButton.OnCheckedChangeListener, View.OnClickListener {
    TextView name,hours,fees,thours,tfees,label;
    Spinner sp;
    RadioButton radio1,radio2;
    CheckBox ch1,ch2;
    Button add,clr;
    ArrayList<courses> corlist = new ArrayList<courses>();
    ArrayList<String> corname = new ArrayList<>();
    public static Double totalHours = 0.0;
    public static Double totalFees = 0.0;
    public static Double currentHours = 0.0;
    public static Double currentFees = 0.0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_course_deatils);

        name = findViewById(R.id.name);
        sp = findViewById(R.id.spinner);
        hours =findViewById(R.id.hours);
        fees = findViewById(R.id.fee);
        radio1 =findViewById(R.id.rd1);
        radio2 = findViewById(R.id.rd2);
        ch1 = findViewById(R.id.checkBox);
        ch2 = findViewById(R.id.checkBox2);
        add = findViewById(R.id.button2);
        label = findViewById(R.id.message);
        clr = findViewById(R.id.clear);
        clr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                radio1.setChecked(true);
                thours.setText("0.0");
                tfees.setText("0.0");
                label.setText("");
            }
        });
        thours = findViewById(R.id.thours);
        tfees = findViewById(R.id.tfees);


        // Display Student name
        String name1 = getIntent().getStringExtra("name");
        name.setText("Welcome "+name1);
        //filldata in spinner
        filldata();
        ArrayAdapter aa = new ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line,corname);
        sp.setAdapter(aa);
        sp.setOnItemSelectedListener(this);
        radio1.setChecked(true);
        hours.setText(String.valueOf(corlist.get(0).getChours()));
        fees.setText(String.valueOf(corlist.get(0).getCfees()));
        radio1.setOnClickListener(this);
        radio2.setOnClickListener(this);

        ch1.setOnCheckedChangeListener(this);
        ch2.setOnCheckedChangeListener(this);



        //Button for add course
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (radio1.isChecked()) {
                    if (totalHours > 19) {
                        label.setText("Sorry you can not add this course");
                        totalHours -= currentHours;
                        totalFees -= currentFees;
                    }
                    if(totalFees.equals(0.0)) {
                        totalHours = currentHours;
                        totalFees = currentFees;
                        thours.setText(String.valueOf(totalHours));
                        tfees.setText(String.valueOf(totalFees));
                    } else {
                        thours.setText(String.valueOf(totalHours));
                        tfees.setText(String.valueOf(totalFees));
                    }
                } else if (radio2.isChecked()) {
                    if (totalHours > 21) {
                        label.setText("Sorry you can not add this course");
                        totalHours -= currentHours;
                        totalFees -= currentFees;
                    }
                    if(totalFees.equals(0.0)) {
                        totalFees = currentFees;
                        totalHours = currentHours;
                        thours.setText(String.valueOf(totalHours));
                        tfees.setText(String.valueOf(totalFees));
                    } else {
                        thours.setText(String.valueOf(totalHours));
                        tfees.setText(String.valueOf(totalFees));
                    }
                }
            }

        });
    }
    // Enter the Data
    public  void filldata() {
        corlist.add(new courses("Java",1300,6));
        corlist.add(new courses("Swift",1500,5));
        corlist.add(new courses("IOS",1350,5));
        corlist.add(new courses("Android",1400,7));
        corlist.add(new courses("Database",1000,4));
        for (int i = 0;i<corlist.size();i++){
            corname.add(corlist.get(i).getCname());

        }
    }

    //Spinner onitemclicked
    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        hours.setText(String.valueOf(corlist.get(position).getChours()));
        fees.setText(String.valueOf(corlist.get(position).getCfees()));
        totalFees += corlist.get(position).getCfees();
        totalHours += corlist.get(position).getChours();

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
    // Checkbox for Add Accomodation and insurance
    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        if(buttonView.getId() == R.id.checkBox)
            if(ch1.isChecked())
                totalFees += 1000;
            else
                totalFees -= 1000;
        if(buttonView.getId() == R.id.checkBox2)
            if(ch2.isChecked())
                totalFees += 700;
            else
                totalFees -= 700;

        tfees.setText(String.valueOf(totalFees));
    }


    @Override
    public void onClick(View v) {

    }
}