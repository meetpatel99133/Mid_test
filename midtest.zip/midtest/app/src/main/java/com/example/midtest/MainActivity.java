package com.example.midtest;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    TextView tname,tuser,tpass;
    Button btn;
    String username = "Student1";
    String Password = "123456";
    //String name = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tname = findViewById(R.id.txtname);
        tuser = findViewById(R.id.txtusername);
        tpass = findViewById(R.id.txtpass);
        btn = findViewById(R.id.button);
        btn.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        if (TextUtils.isEmpty(tuser.getText().toString()) || TextUtils.isEmpty(tname.getText().toString()) || TextUtils.isEmpty(tpass.getText().toString())){
            //code for if anyfiled is empty
            Toast.makeText(MainActivity.this,"Please Enter all Details",Toast.LENGTH_LONG).show();
        }else if (tuser.getText().toString().equals(username)){
            //System will check username is correct or not
            if (tpass.getText().toString().equals(Password)){
                //System will check the password is correct or not
                String name = tname.getText().toString();
                Intent intent = new Intent(MainActivity.this,courseDeatils.class);
                intent.putExtra("name",name);
                startActivity(intent);
            }
        }else
            // if any deatils is wrong it will show the message
            Toast.makeText(MainActivity.this,"Invalid Detials",Toast.LENGTH_LONG).show();

    }
}